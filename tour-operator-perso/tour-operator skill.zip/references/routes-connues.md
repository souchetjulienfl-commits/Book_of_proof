---
name: routes-connues
description: Faits empiriques déjà constatés sur des routes spécifiques (jours de vol opérés, particularités), à consulter avant l'étape 1 du skill tour-operator-perso pour gagner du temps, mais toujours reverifier avant de conclure, ces fréquences peuvent changer.
---

# Routes connues

## ORY ↔ SOF (Orly ↔ Sofia)

- **Transavia** : vole en général uniquement le **vendredi** sur cette route (aller comme retour). Confirmé aussi dans le sens Sofia→Orly (SOF→ORY à l'aller) le 2026-09-14 : seul vendredi 16/10/2026 avait un vol, tous les autres jours de la semaine du 12 au 18/10 affichaient "aucun vol disponible".
- **easyJet** : vole en général le **jeudi**, et parfois le **dimanche**, sur cette route, mais ce n'est pas garanti chaque semaine. Test du 2026-09-14 (semaines du 12/10 et du 19/10/2026, sens SOF→ORY) : seul le **jeudi** (15/10 et 22/10) avait un vol ; le **dimanche** (18/10 et 25/10) affichait explicitement "Aucun vol disponible" sur les deux semaines. Donc : viser le jeudi en priorité, mais vérifier le dimanche au cas par cas plutôt que de le supposer disponible.
- Ryanair ne dessert pas Paris Orly (base parisienne = Beauvais), inutile de le chercher sur une route au départ d'ORY.
- Constaté empiriquement (test du 2026-09-11 puis confirmé par Julien le 2026-09-14, et re-testé le 2026-09-14 dans le sens SOF→ORY). Vérifie quand même à chaque recherche que ça n'a pas changé (nouvelle route, saison différente...) plutôt que de le supposer aveuglément, mais ça permet de directement viser le bon jour de la semaine dans le calendrier au lieu de tâtonner.

## Comparateurs

- **Skyscanner** bloque la navigation automatisée avec un contrôle anti-bot. Constaté le 2026-09-11, puis reconfirmé techniquement le 2026-09-14 : le champ de recherche "De/À" ne remonte plus aucune suggestion, et l'inspection réseau montre que l'API `g/autosuggest-search/api/v1/search-flight/...` répond systématiquement **403 Forbidden** dès qu'un navigateur automatisé l'appelle (pas de CAPTCHA visible cette fois, juste un blocage silencieux de l'autocomplete). Ne pas tenter de contourner, basculer sur un autre comparateur (Google Flights, Kayak) si besoin. Google Flights a fonctionné sans blocage le 2026-09-14 (formulaire classique, pas d'API séparée bloquée).

## Comment enrichir ce fichier

Chaque fois qu'un lancement du skill découvre un fait réutilisable sur une route ou un site (jours opérés, comparateur bloqué, particularité de recherche), ajoute-le ici avec la date de constat, pour que les prochains lancements n'aient pas à le redécouvrir. Ne remplace jamais un fait constaté par une supposition non vérifiée.
